---
name: Mihai Coteț
chamber: Senate
legislature: 2024-2028
---

# Mihai Coteț

**Chamber:** Senate  
**Legislature:** 2024-2028

## Appearances

- [[senate_20260311_2024]]

## Notes

*Senator in the Romanian Senate*

*Last updated: 2026-04-22 03:05:45*
